from .generate import main
main()