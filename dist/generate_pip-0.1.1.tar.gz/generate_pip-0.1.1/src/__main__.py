from .generate_pip import main
main()